import React from "react";
import ReactDOM from "react-dom";
import Sign_in from "./components/Sign_in";
import "./style.css";

ReactDOM.render(<Sign_in />, document.getElementById("root"));
